from flask import Flask, render_template, request

app = Flask(__name__)

# In-memory storage for themes (can be expanded to use a database later)
themes_db = ['space', 'cooking', 'soccer', 'league of legends', 'astronomy', 'football']

# Enhanced explanation function
def generate_explanation(topic, theme):
    explanation = f"Explaining '{topic}' in the context of '{theme}':\n\n"
    
    # Make the topic and theme explanation more detailed and useful
    if theme.lower() in ['space', 'astronomy', 'universe']:
        explanation += f"Imagine you’re an astronaut trying to navigate through the stars and planets. Sorting in space works similarly to arranging celestial bodies based on their size, distance, or other properties. Each planet or star is like an element in an unsorted list."
        explanation += "\n\nLet's use Bubble Sort as an example. In space, let's say you're sorting planets by size. You start by comparing two neighboring planets, and if they’re out of order (i.e., the larger planet is behind a smaller one), you swap them. Then, you move to the next pair of neighboring planets, repeating the process until the entire system of planets is sorted by size."
        explanation += "\n\nThis process is similar to how a spacecraft would reposition itself if there were obstacles ahead, needing to constantly adjust its position until it reaches the desired destination."
        explanation += "\n\n### Example: Sorting Planets by Size Using Bubble Sort:"
        explanation += "\n- Starting from the smallest planet, the astronaut repeatedly compares two planets and swaps them if necessary. Eventually, the astronaut will have sorted the planets by size, just like a Bubble Sort algorithm."
    
    elif theme.lower() in ['cooking', 'recipe', 'food']:
        explanation += f"Think of learning Bubble Sort like preparing a meal, where each ingredient (element) must be added in the right order to ensure the best taste. Bubble Sort works similarly in this context: each element (ingredient) is compared with the next one, and if they're out of order (like adding sugar before salt in a recipe), they are swapped."
        explanation += "\n\nConsider you’re making a sandwich. Each ingredient (lettuce, tomato, cheese, etc.) is like an item in a list. You start by comparing the first two ingredients, and if they’re not in the right order, you swap them. This continues for every ingredient until you’ve made a perfectly ordered sandwich. This process mirrors how Bubble Sort repeatedly compares adjacent items and swaps them until the whole list is in the correct order."
        explanation += "\n\n### Example: Making a Sandwich Using Bubble Sort:"
        explanation += "\n- If you’re sorting the ingredients by freshness (from freshest to oldest), you keep comparing two items at a time and swap them until you have a perfectly ordered sandwich!"
    
    elif theme.lower() in ['soccer', 'football', 'sports']:
        explanation += f"Think of Bubble Sort as organizing your soccer players in the right position on the field. Each player (element) needs to be placed in the correct position based on their skills, whether that’s by speed, skill level, or role on the team."
        explanation += "\n\nIn this context, Bubble Sort works by comparing two players at a time. If one player is stronger than the other, they’re swapped so that the stronger player moves up in the lineup. This process continues until all the players are ranked from weakest to strongest or by any other sorting criteria."
        explanation += "\n\nImagine comparing two soccer players: If Player A is faster than Player B, then Player A takes Player B's position. You repeat this until all players are in the right order. The comparison happens repeatedly, just like in Bubble Sort!"
        explanation += "\n\n### Example: Sorting Soccer Players by Speed Using Bubble Sort:"
        explanation += "\n- You start by comparing two players and swapping them if needed. After several comparisons, the players will be arranged by their speed, just like Bubble Sort sorts elements in a list."

    elif theme.lower() in ['league of legends', 'gaming', 'esports']:
        explanation += f"In a game like League of Legends, imagine sorting your champions by power level or role (e.g., tank, damage dealer). Bubble Sort in this context works like organizing your champions before a match. You need to compare two champions and, if one is stronger than the other, you swap them."
        explanation += "\n\nFor example, in a 5v5 game, you might want to sort your champions by their combat power. If Champion A is stronger than Champion B, you would want Champion A in the front. You keep comparing champions and swapping them until the list is perfectly ordered according to their power level."
        explanation += "\n\n### Example: Sorting Champions by Power Using Bubble Sort:"
        explanation += "\n- Imagine comparing two champions, and swapping them if one is stronger. You keep doing this for every pair of champions until they are ranked in order of their power, just like Bubble Sort organizes elements."
    
    else:
        explanation += f"Since the theme '{theme}' isn't pre-defined, here's a basic analogy:\n\n{topic} is an algorithm or concept that involves arranging elements in a specific order. Much like organizing items on a shelf, you check each item, and if they’re out of order, you swap them. This is a comparison-based sorting method, and the process repeats itself until everything is in the right order."
    
    # Make the explanation sound more conversational and engaging
    explanation += "\n\nBubble Sort is simple but effective. It’s not the fastest for large datasets, but it is an excellent way to understand the basic principle of sorting—comparing and swapping items to get them in the correct order."
    
    return explanation


@app.route('/')
def home():
    return render_template('index.html', themes=themes_db)

@app.route('/get_response', methods=['POST'])
def get_response():
    topic = request.form['topic'].strip()
    theme = request.form['theme'].strip()

    if not topic or not theme:
        return render_template('index.html', response="Please provide both a topic and a theme.", themes=themes_db)

    response = generate_explanation(topic, theme)
    return render_template('index.html', response=response, themes=themes_db)

@app.route('/add_theme', methods=['POST'])
def add_theme():
    new_theme = request.form['new_theme'].strip().lower()

    # Check if the new theme is not empty and not already in the list
    if new_theme and new_theme not in themes_db:
        themes_db.append(new_theme)
        return render_template('index.html', message=f"'{new_theme}' has been added as a theme!", themes=themes_db)
    elif new_theme in themes_db:
        return render_template('index.html', message="This theme already exists. Try a different one.", themes=themes_db)
    else:
        return render_template('index.html', message="Please enter a valid theme.", themes=themes_db)

if __name__ == '__main__':
    app.run(debug=True)
